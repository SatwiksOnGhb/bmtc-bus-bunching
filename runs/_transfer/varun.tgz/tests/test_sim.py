"""Simulation checks. Skipped when SUMO is not installed."""
import os
import shutil

import numpy as np
import pytest

sumo_available = bool(os.environ.get("SUMO_HOME")) or shutil.which("sumo")
pytestmark = pytest.mark.skipif(not sumo_available, reason="SUMO not installed")


def short_config(**kw):
    from sim.bus_sim import SimConfig
    return SimConfig(begin=25200, end=27000, **kw)   # 07:00-07:30 departures


def test_scenario_routes_have_no_u_turns():
    from sim import scenario
    for name, (edges, stops) in scenario.route_definitions().items():
        assert len(stops) == 23, name
        assert not any(edges[i + 1] == scenario.reverse_id(edges[i]) for i in range(len(edges) - 1)), name


def test_baseline_episode_runs_without_teleports():
    from control.baselines import BaselinePolicy
    from sim.bus_sim import BusSim
    sim = BusSim(short_config(policy="two_headway"))
    policy = BaselinePolicy("two_headway", sim.settings.holding)
    obs = sim.reset()
    while not sim.done:
        assert all(o.can_hold for o in obs.values())
        obs = sim.step(policy.act(obs))
    k = sim.kpis()
    assert k["completed_trips_n"] == len(sim.all_trips)
    assert k["teleports"] == 0
    assert k["headway_cv"] is not None


def test_same_seed_is_reproducible():
    from sim.bus_sim import BusSim
    results = []
    for _ in range(2):
        sim = BusSim(short_config(seed=3))
        sim.reset()
        while not sim.done:
            sim.step({})
        results.append(sim.kpis()["mean_trip_time_s"])
    assert results[0] == results[1]


def test_env_api():
    from sim.env import OBS_DIM, BusHoldingEnv
    env = BusHoldingEnv(short_config(policy="rl"))
    obs, infos = env.reset(seed=1)
    rng = np.random.default_rng(0)
    steps = 0
    while env.agents:
        for a, o in obs.items():
            assert o.shape == (OBS_DIM,) and np.isfinite(o).all()
        assert env.state().shape == env.state_space.shape
        actions = {a: int(rng.integers(env.action_space(a).n)) for a in env.agents}
        obs, rewards, terms, truncs, infos = env.step(actions)
        assert set(rewards) == set(obs)
        steps += 1
    assert steps > 0 and all(terms.values())
