"""Run route 375-D (Banashankari -> Kengeri) in SUMO with passengers, dwell time and holding.

Usage (from the bmtc folder):
    python -m sim.run_375d                      # 4 policies x 3 seeds, then plots
    python -m sim.run_375d --policies no_control --seeds 1 --gui   # watch one run
"""
import argparse
import csv
import json
import math
import os
import random
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict, deque
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
if "SUMO_HOME" in os.environ:
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))
import sumolib  # noqa: E402
import traci  # noqa: E402

from common.kpis import compute_kpis  # noqa: E402
from common.schemas import BusObservation, StopArrival, VehicleTrip  # noqa: E402
from common.settings import load_settings  # noqa: E402
from control.baselines import BaselinePolicy  # noqa: E402

SUMO_DIR = ROOT / "runs" / "sumo"
OUT_DIR = ROOT / "runs" / "holding"
ROUTE_ID = "NjndpGKT:0TM4gTTy"   # 375-D towards Kengeri Bus Stand
ROUTE_NAME = "375-D"
POLICIES = ("no_control", "schedule", "daganzo", "two_headway")

CAPACITY = 80             # passengers per bus
DWELL_FIXED_S = 4.0       # door open/close
BOARD_S = 2.0             # seconds per boarding passenger
ALIGHT_S = 1.2            # seconds per alighting passenger
HOLD_STOP_DURATION = 100000  # buses wait at every stop until the script releases them


def build_route_file(begin, end):
    """Copy the 375-D pattern out of the gtfs2pt output, without timetable 'until' constraints."""
    tree = ET.parse(SUMO_DIR / "gtfs_pt_vehicles.add.xml")
    root = tree.getroot()
    route = next(r for r in root.iter("route") if r.get("id") == ROUTE_ID)
    stops = [(s.get("busStop"), float(s.get("until", 0))) for s in route.iter("stop")]
    departs = sorted(float(v.get("depart")) for v in root.iter("vehicle")
                     if v.get("route") == ROUTE_ID and begin <= float(v.get("depart")) < end)
    lines = ['<routes>',
             '    <vType id="bus375" vClass="bus" length="12" speedDev="0.1" sigma="0.5"/>',
             f'    <route id="r375" edges="{route.get("edges")}">']
    for stop_id, _ in stops:
        lines.append(f'        <stop busStop="{stop_id}" duration="{HOLD_STOP_DURATION}"/>')
    lines.append('    </route>')
    for i, dep in enumerate(departs):
        lines.append(f'    <vehicle id="bus{i:03d}" type="bus375" route="r375" depart="{dep:.0f}" line="{ROUTE_NAME}"/>')
    lines.append('</routes>')
    path = SUMO_DIR / "375d.rou.xml"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path, stops, departs


class Demand:
    """Poisson passenger arrivals per stop, with a morning peak around 08:30."""

    def __init__(self, n_stops, base_per_min, rng):
        self.rng, self.base = rng, base_per_min / 60.0
        self.queue = [deque() for _ in range(n_stops)]
        self.next_t = [None] * n_stops
        self.n = n_stops

    def rate(self, t):
        return self.base * (1 + 0.8 * math.exp(-((t - 30600) / 3600) ** 2))

    def update(self, k, t):
        if k == self.n - 1:          # nobody boards at the last stop
            return
        if self.next_t[k] is None:
            self.next_t[k] = t
        while self.next_t[k] <= t:
            self.queue[k].append(self.next_t[k])
            self.next_t[k] += self.rng.expovariate(self.rate(self.next_t[k]))


def run_once(policy_name, seed, args, config):
    rng = random.Random(seed)
    rou, stops, departs = build_route_file(args.begin, args.end)
    stop_index = {sid: k for k, (sid, _) in enumerate(stops)}
    offsets = [until for _, until in stops]
    n = len(stops)
    order = [f"bus{i:03d}" for i in range(len(departs))]
    depart_of = dict(zip(order, departs))
    sched_hw = {}
    for i, bus in enumerate(order):
        gap = departs[i] - departs[i - 1] if i > 0 else (departs[1] - departs[0] if len(departs) > 1 else 0)
        sched_hw[bus] = gap if gap > 0 else None

    binary = sumolib.checkBinary("sumo-gui" if args.gui else "sumo")
    traci.start([binary, "-n", str(SUMO_DIR / "bmtc.net.xml"),
                 "-a", str(SUMO_DIR / "gtfs_pt_stops.add.xml"), "-r", str(rou),
                 "--begin", str(args.begin), "--end", str(args.end + 7200),
                 "--seed", str(seed), "--time-to-teleport", "300",
                 "--ignore-route-errors", "true", "--no-step-log", "true", "--no-warnings", "true"])

    policy = BaselinePolicy(policy_name, config.holding)
    demand = Demand(n, args.demand, rng)
    load = defaultdict(int)
    onboard_wait = []
    last_arrival = [None] * n      # previous bus arrival time at each stop
    last_stop = {}                 # bus -> (stop_idx, time)
    at_stop = set()
    release = {}
    actual_depart = {}
    arrivals, trips, wait_times, holds_log = [], [], [], []
    episode = f"{policy_name}-s{seed}"

    while True:
        traci.simulationStep()
        t = traci.simulation.getTime()
        for v in traci.simulation.getDepartedIDList():
            actual_depart[v] = t
        for v in traci.simulation.getArrivedIDList():
            if v in actual_depart:
                trips.append(VehicleTrip(departure_s=actual_depart[v], arrival_s=t))
            at_stop.discard(v)
            release.pop(v, None)

        for v, t_rel in list(release.items()):
            if t >= t_rel:
                traci.vehicle.resume(v)
                del release[v]
                at_stop.discard(v)

        for v in traci.vehicle.getIDList():
            if v in at_stop or not traci.vehicle.isAtBusStop(v):
                continue
            nxt = traci.vehicle.getStops(v, 1)
            if not nxt or nxt[0].stoppingPlaceID not in stop_index:
                continue
            k = stop_index[nxt[0].stoppingPlaceID]
            at_stop.add(v)

            demand.update(k, t)
            waiting = len(demand.queue[k])
            alight = load[v] if k == n - 1 else sum(rng.random() < 1 / (n - k) for _ in range(load[v]))
            load[v] -= alight
            board = min(waiting, CAPACITY - load[v])
            for _ in range(board):
                wait_times.append(t - demand.queue[k].popleft())
            load[v] += board
            dwell = DWELL_FIXED_S + BOARD_S * board + ALIGHT_S * alight

            fwd = t - last_arrival[k] if last_arrival[k] is not None else None
            i = order.index(v)
            bwd = None
            if i + 1 < len(order):
                f = order[i + 1]
                if f in last_stop:
                    kf, tf = last_stop[f]
                    bwd = max(0.0, (offsets[k] - offsets[kf]) - (t - tf))
                else:
                    bwd = max(0.0, depart_of[f] + offsets[k] - t)
            x, y = traci.vehicle.getPosition(v)
            lon, lat = traci.simulation.convertGeo(x, y)
            obs = BusObservation(
                bus_id=v, route_id=ROUTE_NAME, t=t, stop_idx=k, lat=lat, lon=lon,
                fwd_headway_s=fwd, bwd_headway_s=bwd,
                sched_dev_s=t - (depart_of[v] + offsets[k]),
                load=load[v], waiting_at_stop=waiting, scheduled_headway_s=sched_hw[v],
                can_hold=0 < k < n - 1)
            hold = policy.act({v: obs})[v]
            release[v] = t + math.ceil(dwell) + hold
            last_arrival[k] = t
            last_stop[v] = (k, t)
            holds_log.append(hold)
            arrivals.append(StopArrival(
                **obs.model_dump(), episode_id=episode, trip_id=v, pattern_id=ROUTE_ID,
                stop_id=stops[k][0], scenario="375d_base", policy=policy_name, seed=seed,
                dwell_s=dwell, hour_ist=int(t // 3600) % 24, data_source="simulation"))

        if t >= args.end and traci.simulation.getMinExpectedNumber() == 0:
            break
        if t >= args.end + 7200:
            break
    traci.close()

    kpis = compute_kpis(arrivals, (), trips, bunching_ratio=config.bunching.ratio)
    kpis["mean_passenger_wait_s"] = mean(wait_times) if wait_times else None
    kpis["passengers_boarded_n"] = len(wait_times)
    kpis["mean_hold_s"] = mean(holds_log) if holds_log else None
    return kpis, arrivals


def plot(results, arrivals_by_policy):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    metrics = [("bunched_arrivals_pct", "Bunched arrivals (%)"), ("headway_cv", "Headway CV"),
               ("mean_passenger_wait_s", "Mean passenger wait (s)"), ("mean_trip_time_s", "Mean trip time (s)")]
    fig, axes = plt.subplots(1, 4, figsize=(16, 4))
    for ax, (key, label) in zip(axes, metrics):
        vals = [[r[key] for r in results if r["policy"] == p and r[key] is not None] for p in POLICIES]
        ax.bar(POLICIES, [mean(v) if v else 0 for v in vals], color="#4C78A8")
        ax.set_title(label)
        ax.tick_params(axis="x", rotation=30)
    fig.suptitle("375-D holding baselines (mean over seeds)")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "comparison.png", dpi=150)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5), sharey=True)
    for ax, p in zip(axes, ("no_control", "two_headway")):
        by_bus = defaultdict(list)
        for a in arrivals_by_policy.get(p, []):
            by_bus[a.bus_id].append((a.t / 3600, a.stop_idx))
        for pts in by_bus.values():
            pts.sort()
            ax.plot([x for x, _ in pts], [y for _, y in pts], lw=0.8)
        ax.set_title(f"Time-space diagram: {p}")
        ax.set_xlabel("Time of day (h)")
    axes[0].set_ylabel("Stop index")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "time_space.png", dpi=150)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policies", nargs="+", default=list(POLICIES), choices=POLICIES)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--begin", type=int, default=25200, help="sim start, seconds after midnight (07:00)")
    ap.add_argument("--end", type=int, default=39600, help="last departure, seconds after midnight (11:00)")
    ap.add_argument("--demand", type=float, default=1.5, help="passengers per minute per stop (off-peak)")
    ap.add_argument("--gui", action="store_true")
    args = ap.parse_args()

    config = load_settings(ROOT / "common" / "config.yaml")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    results, arrivals_by_policy = [], {}
    for p in args.policies:
        for seed in range(1, args.seeds + 1):
            print(f"Running {p} seed {seed} ...", flush=True)
            kpis, arrivals = run_once(p, seed, args, config)
            results.append({"policy": p, "seed": seed, **kpis})
            print(f"  bunched {kpis['bunched_arrivals_pct']:.1f}%  headway CV {kpis['headway_cv']:.2f}  "
                  f"wait {kpis['mean_passenger_wait_s']:.0f}s  trips {kpis['completed_trips_n']}", flush=True)
            arrivals_by_policy.setdefault(p, arrivals)
            with open(OUT_DIR / f"arrivals_{p}_s{seed}.csv", "w", newline="", encoding="utf-8") as fh:
                w = csv.DictWriter(fh, fieldnames=list(arrivals[0].model_dump().keys()))
                w.writeheader()
                w.writerows(a.model_dump() for a in arrivals)

    with open(OUT_DIR / "results.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(results[0].keys()))
        w.writeheader()
        w.writerows(results)
    print("\nMean over seeds:")
    for p in args.policies:
        rows = [r for r in results if r["policy"] == p]
        print(f"  {p:12} bunched {mean(r['bunched_arrivals_pct'] for r in rows):5.1f}%  "
              f"CV {mean(r['headway_cv'] for r in rows):.2f}  "
              f"wait {mean(r['mean_passenger_wait_s'] for r in rows):4.0f}s  "
              f"trip {mean(r['mean_trip_time_s'] for r in rows):5.0f}s")
    plot(results, arrivals_by_policy)
    print(f"\nSaved results.csv, comparison.png and time_space.png in {OUT_DIR}")


if __name__ == "__main__":
    main()
