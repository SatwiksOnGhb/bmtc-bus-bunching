# Part 2 · Satwik's SUMO simulation (hand-off to Vikas)

Route **375-D** (Banashankari Bus Station ⇄ Kengeri Bus Stand, 23 stops each way, about 11.5 km) runs in SUMO on the real Bengaluru road network, with passengers, dwell time, Varun's 2019 BMTC GPS speeds and holding control at stops. The same simulator backs the rule-based baselines and a PettingZoo multi-agent environment for RL.

## Quick start (Windows, from the `bmtc` folder)

```powershell
py -3.14 -m pip install pandas pydantic pyyaml matplotlib pettingzoo gymnasium rtree pyproj
py -3.14 -m pytest -q tests                       # Varun's tests + 4 simulation tests
py -3.14 -m sim.run_375d                          # 4 baselines x 5 seeds, about 10 minutes
py -3.14 -m sim.run_375d --seeds 1 --policies daganzo --gui   # watch it in sumo-gui
```

SUMO 1.28 must be installed with `SUMO_HOME` set. Results go to `runs/holding/`.

## Files

| File | What it is |
| --- | --- |
| `sim/scenario.py` | One-off build of the 375-D scenario from the city-wide import (already run; outputs are in `runs/sumo/`). |
| `sim/bus_sim.py` | The simulator. `BusSim(SimConfig(...))`, `reset()`, `step(holds)`, `kpis()`. |
| `sim/env.py` | `BusHoldingEnv`, the PettingZoo environment for Vikas. |
| `sim/run_375d.py` | Runs Varun's four holding rules and makes the charts. |
| `tests/test_sim.py` | No U-turns, no teleports, reproducible seeds, environment API. |
| `runs/sumo/375d.net.xml` | Road network cut to the 463 road segments 375-D uses (loads in about a second). |
| `runs/sumo/375d_stops.add.xml`, `375d_routes.json` | 46 stops on the correct side of the road and the route through them. |
| `runs/sumo/edge_hour_speeds.csv` | Varun's GPS speeds joined to this network (`python -m data.sumo_speeds`). |
| `runs/holding/` | `summary.csv`, `results.csv`, per-run stop logs (`arrivals_*.csv`), `comparison.png`, `time_space.png`. |

## How the simulation works

- **Schedule.** Every 375-D trip departing between 07:00 and 11:00 on 16 Nov 2026 (Varun's `scheduled_arrivals.csv`). Bus IDs are GTFS `trip_id`s and stop indices match `pattern_stops.csv`, so every log row joins back to Varun's tables.
- **Road speeds.** Each hour the simulator sets each road segment's speed to Varun's measured median BMTC bus speed for that segment and hour (183 and 195 of the 235 segments in each direction have data). Segments without data use the 375-D corridor median for that hour. Traffic lights come from OpenStreetMap. Buses vary ±10% in speed.
- **Passengers.** They arrive at each stop at random (Poisson), 0.4 per minute per stop, doubling around the 08:30 peak. Each picks a random stop further along. Buses carry at most 80.
- **Dwell.** 4 s + 2.0 s per boarding + 1.2 s per alighting. A late bus meets more waiting passengers, dwells longer and falls further behind. That feedback is what creates bunching.
- **Holding.** At every stop except the first and last, the controller picks a hold from `config.yaml` (`0, 15, 30, 45, 60, 90` s) on top of dwell.
- **Observation.** Exactly Varun's `BusObservation`. Forward headway is the time since the previous bus arrived at this stop. Backward headway is the time until the next bus is expected here, based on its last stop and the timetable's running time. `sched_dev_s` is positive when late.
- **Logs and KPIs.** One `StopArrival` per bus per stop, `PassengerTrip` per passenger, and `VehicleTrip` per bus, fed into Varun's `compute_kpis`.

## Baseline results (5 seeds, both directions, 07:00–11:00)

| Policy | Headway CV | Bunched (< 20%, Varun) | Bunched (< 50%) | Mean wait (s) | Trip time (s) | Mean hold (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| No control | 0.69 | 15.5% | 24.5% | 299 | 3181 | 0 |
| Schedule | 0.67 | 14.6% | 23.8% | 298 | 3195 | 0.8 |
| Daganzo (forward headway) | **0.43** | **0.0%** | **0.4%** | **250** | 3372 | 15.3 |
| Two-headway | 0.53 | 5.9% | 15.1% | 262 | 3203 | 5.3 |

- **Daganzo** almost eliminates bunching and cuts waits by 16%, but adds about 3 minutes (6%) to every trip.
- **Two-headway** gets about half that improvement for only 22 seconds of extra trip time.
- **Schedule holding** barely acts: buses here are slower than the timetable, so they are rarely early enough to hold.
- **Target for RL:** reach Daganzo's regularity (CV ≈ 0.43, near-zero bunching) with two-headway's trip time (≈ 3200 s).

## For Vikas: the RL environment

```python
from sim.env import BusHoldingEnv
env = BusHoldingEnv()                 # 88 bus agents, Discrete(6) actions, 10-value observations
obs, infos = env.reset(seed=1)
while env.agents:                     # agents = buses currently waiting for a hold decision
    actions = {a: policy(obs[a]) for a in env.agents}
    obs, rewards, terminations, truncations, infos = env.step(actions)
print(env.kpis())                     # same KPIs as the baselines
```

- **Event-driven.** Buses appear in `env.agents` only when they reach a stop where holding is allowed. Use parameter sharing (one policy for all buses), as in MAPPO or IPPO.
- **Reward (semi-Markov).** It arrives with the bus's next decision: `−|fwd − bwd| / H − 0.1 · previous hold / H`, where `H` is the scheduled headway. `infos[bus]["elapsed_s"]` gives the time since that decision, for discounting. Change it in `BusHoldingEnv._package` if needed.
- **Centralised critic.** `env.state()` is a 160-value global state: 20 buses × 4 features × 2 directions.
- **Baselines through the env:** `hold_indices(BaselinePolicy(...).act(infos[a]["bus_observation"]...), env.actions_s)`. Two-headway through the env reproduces the table above exactly.
- **Speed.** One episode (about 1,750 decisions) takes about 25 s. For parallel workers, give each process its own environment; route files are named by process ID, so they don't clash.
- **Evaluation.** Evaluate on seeds not used for training (for example 101–105) and compare with the table above.

## Known limitations (put these in the report)

1. **Speeds are from August 2019 (pre-COVID).** With them, simulated trips take about 53 min, against 34 min in the 2026 timetable. The GPS medians include slowing near stops, and SUMO adds its own braking at stops, so the simulation may run somewhat slow.
2. **Passenger demand is assumed**, not measured. BMTC stop-level ridership is not public. Try `--demand 0.2` and `--demand 0.6` as a sensitivity check.
3. **The timetable has near-duplicate trips.** 21 of 109 trips in the window depart 0–60 s after another trip on the same pattern, including 4 at the same second. The simulator keeps one trip per 2 minutes (`min_departure_gap_s`) and recomputes scheduled headways. Varun should check whether these are duplicates in the source feed.
4. **Stops were re-snapped.** `gtfs2pt.py` put 19 of 46 stops on the wrong side of the road, causing U-turn detours and SUMO teleports. `sim/scenario.py` moves each stop to the side that gives the shortest route, which leaves 0 U-turns and 0 teleports in all 20 baseline runs.
5. **Trips are not linked.** Each trip is a separate bus, and buses don't turn around at the terminal. There is no other traffic besides buses.
6. **Varun's 20% bunching threshold is strict.** The table also reports the 50% threshold and headway CV.
