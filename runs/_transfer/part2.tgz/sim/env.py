"""PettingZoo environment for multi-agent bus holding on route 375-D.

Each bus (one GTFS trip) is an agent. The environment is event-driven: an agent appears in
`env.agents` only when its bus has just arrived at a stop where holding is allowed, and
it then chooses a hold time from config holding.actions_s (default 0, 15, 30, 45, 60, 90 s).

    from sim.env import BusHoldingEnv
    env = BusHoldingEnv()
    obs, infos = env.reset(seed=1)
    while env.agents:
        actions = {a: env.action_space(a).sample() for a in env.agents}
        obs, rewards, terminations, truncations, infos = env.step(actions)

Rewards are semi-Markov: an agent's reward for a hold arrives with its NEXT observation,
together with infos[agent]["elapsed_s"] (seconds since that decision) for discounting.
Buses whose trip has ended get a final reward of 0 with terminations[agent] = True when
the episode finishes.

Observation (float32, OBS_DIM values; H = scheduled headway at this stop):
    0 forward headway / H        1 forward headway known (0/1)
    2 backward headway / H       3 backward headway known (0/1)
    4 schedule deviation / H (positive = late, clipped to ±5)
    5 load / capacity            6 waiting passengers / capacity
    7 stop index / last stop     8 direction (0 to Kengeri, 1 to Banashankari)
    9 fraction of the episode elapsed
env.state() returns a fixed-size global vector for a centralised critic (MAPPO).
"""
import numpy as np
from gymnasium import spaces
from pettingzoo import ParallelEnv

from sim.bus_sim import BusSim, SimConfig

OBS_DIM = 10
MAX_BUSES_PER_DIRECTION = 20
STATE_FEATURES = 4
DEFAULT_HEADWAY_S = 300.0


class BusHoldingEnv(ParallelEnv):
    metadata = {"name": "bmtc_375d_holding_v0", "render_modes": []}

    def __init__(self, sim_config: SimConfig = None, hold_penalty: float = 0.1):
        self.sim = BusSim(sim_config or SimConfig(policy="rl"))
        self.actions_s = self.sim.actions_s
        self.hold_penalty = hold_penalty
        self.possible_agents = self.sim.trip_ids()
        self._obs_space = spaces.Box(-5.0, 5.0, (OBS_DIM,), np.float32)
        self._act_space = spaces.Discrete(len(self.actions_s))
        n_dirs = len(self.sim.cfg.directions)
        self.state_space = spaces.Box(-5.0, 5.0, (n_dirs * MAX_BUSES_PER_DIRECTION * STATE_FEATURES,), np.float32)
        self.agents = []

    def observation_space(self, agent):
        return self._obs_space

    def action_space(self, agent):
        return self._act_space

    # ----------------------------------------------------------------- helpers
    def _vector(self, obs):
        d = self.sim.dir_of[obs.bus_id]
        h = obs.scheduled_headway_s or DEFAULT_HEADWAY_S
        cap = self.sim.cfg.capacity
        cfg = self.sim.cfg
        return np.array([
            0.0 if obs.fwd_headway_s is None else min(obs.fwd_headway_s / h, 5.0),
            float(obs.fwd_headway_s is not None),
            0.0 if obs.bwd_headway_s is None else min(obs.bwd_headway_s / h, 5.0),
            float(obs.bwd_headway_s is not None),
            float(np.clip(obs.sched_dev_s / h, -5.0, 5.0)),
            obs.load / cap,
            min(obs.waiting_at_stop / cap, 5.0),
            obs.stop_idx / (d.n - 1),
            float(list(self.sim.dirs).index(d.name)),
            min((obs.t - cfg.begin) / max(cfg.end - cfg.begin, 1), 5.0),
        ], dtype=np.float32)

    def _regularity(self, obs):
        h = obs.scheduled_headway_s or DEFAULT_HEADWAY_S
        if obs.fwd_headway_s is not None and obs.bwd_headway_s is not None:
            return -abs(obs.fwd_headway_s - obs.bwd_headway_s) / h
        if obs.fwd_headway_s is not None:
            return -abs(obs.fwd_headway_s - h) / h
        return 0.0

    def state(self):
        rows = []
        for d in self.sim.dirs.values():
            buses = [t for t in d.trips if t in self.sim.depart_t and t not in self.sim.finished]
            feats = []
            for bus in buses[:MAX_BUSES_PER_DIRECTION]:
                k, t_k = self.sim.last_stop.get(bus, (0, self.sim.t))
                h = d.sched_hw[bus][k] or DEFAULT_HEADWAY_S
                feats.append([k / (d.n - 1), min((self.sim.t - t_k) / h, 5.0),
                              len(self.sim.onboard[bus]) / self.sim.cfg.capacity,
                              float(np.clip((self.sim.t - d.sched[bus][k]) / h, -5, 5))])
            feats += [[0.0] * STATE_FEATURES] * (MAX_BUSES_PER_DIRECTION - len(feats))
            rows.extend(feats)
        return np.asarray(rows, dtype=np.float32).ravel()

    def _package(self, pending):
        obs, rewards, infos = {}, {}, {}
        for bus, o in pending.items():
            obs[bus] = self._vector(o)
            prev = self._last_decision.get(bus)
            if prev is None:
                rewards[bus], elapsed = 0.0, 0.0
            else:
                t_prev, hold_prev, h_prev = prev
                rewards[bus] = self._regularity(o) - self.hold_penalty * hold_prev / h_prev
                elapsed = o.t - t_prev
            infos[bus] = {"bus_observation": o, "elapsed_s": elapsed}
        return obs, rewards, infos

    # --------------------------------------------------------------------- API
    def reset(self, seed=None, options=None):
        self._last_decision = {}
        pending = self.sim.reset(seed=seed)
        obs, _, infos = self._package(pending)
        self.agents = list(obs)
        return obs, infos

    def step(self, actions):
        holds = {}
        for bus in self.agents:
            idx = int(actions.get(bus, 0))
            hold = self.actions_s[idx]
            holds[bus] = hold
            o = self.sim.pending[bus][0]
            self._last_decision[bus] = (o.t, hold, o.scheduled_headway_s or DEFAULT_HEADWAY_S)
        pending = self.sim.step(holds)
        obs, rewards, infos = self._package(pending)
        terminations = {bus: False for bus in obs}
        truncations = {bus: False for bus in obs}
        if self.sim.done:
            for bus in self._last_decision:
                obs.setdefault(bus, np.zeros(OBS_DIM, np.float32))
                rewards.setdefault(bus, 0.0)
                infos.setdefault(bus, {"elapsed_s": 0.0})
                terminations[bus] = True
                truncations[bus] = False
            self.agents = []
        else:
            self.agents = list(pending)
        return obs, rewards, terminations, truncations, infos

    def kpis(self):
        return self.sim.kpis()

    def close(self):
        self.sim.close()
