"""Event-driven SUMO simulation of route 375-D with passengers, dwell time and holding.

The simulator stops whenever buses arrive at a stop where holding is allowed and asks
for a hold time. Everything else (passengers, dwell, road speeds) runs inside.

    sim = BusSim(SimConfig(seed=1))
    obs = sim.reset()                       # {bus_id: BusObservation}
    while not sim.done:
        holds = policy.act(obs)             # {bus_id: hold seconds}
        obs = sim.step(holds)
    print(sim.kpis())

bus_id is the GTFS trip_id, so every log row joins back to Varun's schedule tables.
"""
import itertools
import math
import os
import random
import sys
import tempfile
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from statistics import mean

import pandas as pd

if "SUMO_HOME" in os.environ:
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))
import sumolib  # noqa: E402
import traci  # noqa: E402

from common.kpis import compute_kpis  # noqa: E402
from common.schemas import BusObservation, PassengerTrip, StopArrival, VehicleTrip  # noqa: E402
from common.settings import load_settings  # noqa: E402
from sim import scenario  # noqa: E402

_labels = itertools.count()


@dataclass
class SimConfig:
    begin: int = 25200                 # 07:00 IST, seconds after midnight
    end: int = 39600                   # 11:00 IST, last scheduled departure included
    seed: int = 1
    directions: tuple = ("to_kengeri", "to_banashankari")
    min_departure_gap_s: int = 120     # drop timetable trips closer than this to the previous one
    demand_per_min: float = 0.4        # passengers per minute per stop, off-peak
    peak_factor: float = 1.0           # extra demand at the 08:30 peak (1.0 = double)
    capacity: int = 80
    dwell_fixed_s: float = 4.0
    board_s: float = 2.0
    alight_s: float = 1.2
    gps_speeds: bool = True            # use Varun's measured 2019 BMTC speeds by road and hour
    speed_dev: float = 0.1             # bus-to-bus speed variation
    gui: bool = False
    scenario: str = "375d_base"
    policy: str = "unknown"
    extra_sumo_args: list = field(default_factory=list)


@dataclass
class Passenger:
    arrive_t: float
    origin: int
    dest: int
    board_t: float = 0.0


class Demand:
    """Poisson arrivals per stop with a morning peak; destinations uniform downstream."""

    def __init__(self, n_stops, cfg: SimConfig, rng):
        self.n, self.cfg, self.rng = n_stops, cfg, rng
        self.queue = [deque() for _ in range(n_stops)]
        self.next_t = [None] * n_stops

    def rate(self, t):
        per_min = self.cfg.demand_per_min * (1 + self.cfg.peak_factor * math.exp(-((t - 30600) / 3600) ** 2))
        return per_min / 60.0

    def update(self, k, t):
        if k >= self.n - 1 or self.cfg.demand_per_min <= 0:
            return
        if self.next_t[k] is None:
            self.next_t[k] = self.cfg.begin + self.rng.expovariate(self.rate(self.cfg.begin))
        while self.next_t[k] <= t:
            self.queue[k].append(Passenger(self.next_t[k], k, self.rng.randint(k + 1, self.n - 1)))
            self.next_t[k] += self.rng.expovariate(self.rate(self.next_t[k]))


class Direction:
    """Schedule and live state for one direction of the route."""

    def __init__(self, name, cfg, schedule, edges, stops, rng):
        self.name = name
        self.pattern_id = scenario.DIRECTIONS[name][0]
        self.edges, self.stops = edges, stops
        self.n = len(stops)
        rows = schedule[schedule.pattern_id == self.pattern_id]
        first = rows[rows.stop_idx == 0].set_index("trip_id").departure_s
        trips = first[(first >= cfg.begin) & (first < cfg.end)].sort_values()
        # The feed has trips 0-60 s apart (likely duplicates). Keep one per min_departure_gap_s.
        kept, last = [], None
        for trip, dep in trips.items():
            if last is None or dep - last >= cfg.min_departure_gap_s:
                kept.append(trip)
                last = dep
        self.dropped_trips = len(trips) - len(kept)
        trips = trips[kept]
        self.trips = list(trips.index)
        rows = rows[rows.trip_id.isin(self.trips)]
        if (rows.groupby("trip_id").size() != self.n).any():
            raise ValueError(f"{name}: GTFS stop count differs from the SUMO route ({self.n} stops)")
        self.sched = {t: g.sort_values("stop_idx").arrival_s.tolist() for t, g in rows.groupby("trip_id")}
        # Scheduled headway at each stop = gap to the previous kept trip (first trip: next gap).
        self.sched_hw = {}
        for i, t in enumerate(self.trips):
            other = self.trips[i - 1] if i > 0 else (self.trips[1] if len(self.trips) > 1 else None)
            self.sched_hw[t] = [abs(self.sched[t][k] - self.sched[other][k]) or None if other else None
                                for k in range(self.n)]
        self.depart = trips.to_dict()
        self.follower = dict(zip(self.trips, self.trips[1:]))
        self.demand = Demand(self.n, cfg, rng)
        self.last_arrival = [None] * self.n
        self.stop_index = {s: k for k, s in enumerate(stops)}


class BusSim:
    def __init__(self, cfg: SimConfig = None):
        self.cfg = cfg or SimConfig()
        self.settings = load_settings(scenario.ROOT / "common" / "config.yaml")
        self.actions_s = self.settings.holding.actions_s
        self._schedule = pd.read_csv(scenario.SCHEDULE)
        self._routes = scenario.route_definitions()
        self._speeds = self._load_speeds() if self.cfg.gps_speeds else None
        self.conn = None
        self.label = f"bmtc{next(_labels)}"

    # ----------------------------------------------------------------- setup
    def _load_speeds(self):
        edges = pd.read_csv(scenario.EDGE_SPEEDS)
        edge_speed = {(r.edge_id, int(r.hour_ist)): r.median_speed_mps for r in edges.itertuples()}
        corr = pd.read_csv(scenario.CORRIDOR_SPEEDS)
        corr = corr[corr.route_id == scenario.ROUTE_ID]
        corridor = {int(r.hour_ist): r.median_speed_kmh / 3.6 for r in corr.itertuples()}
        return edge_speed, corridor

    def _write_routes(self):
        lines = ["<routes>",
                 f'    <vType id="bus" vClass="bus" length="12" speedDev="{self.cfg.speed_dev}" sigma="0.5"/>']
        vehicles = []
        for d in self.dirs.values():
            lines.append(f'    <route id="{d.name}" edges="{" ".join(d.edges)}">')
            lines += [f'        <stop busStop="{s}" duration="100000"/>' for s in d.stops]
            lines.append("    </route>")
            vehicles += [(d.depart[t], t, d.name) for t in d.trips]
        for dep, trip, route in sorted(vehicles):
            lines.append(f'    <vehicle id="{trip}" type="bus" route="{route}" depart="{dep:.0f}" '
                         f'line="{scenario.ROUTE_NAME}"/>')
        lines.append("</routes>")
        path = Path(tempfile.gettempdir()) / f"bmtc_375d_{os.getpid()}_{self.label}.rou.xml"
        path.write_text("\n".join(lines), encoding="utf-8")
        return path

    def trip_ids(self):
        """All bus (trip) ids of an episode, without starting SUMO."""
        dirs = [Direction(name, self.cfg, self._schedule, *self._routes[name], random.Random(0))
                for name in self.cfg.directions]
        return [t for d in dirs for t in d.trips]

    def reset(self, seed=None):
        if seed is not None:
            self.cfg.seed = seed
        self.close()
        self.rng = random.Random(self.cfg.seed)
        self.dirs = {name: Direction(name, self.cfg, self._schedule, *self._routes[name], self.rng)
                     for name in self.cfg.directions}
        self.dir_of = {t: d for d in self.dirs.values() for t in d.trips}
        self.all_trips = [t for d in self.dirs.values() for t in d.trips]
        routes = self._write_routes()
        binary = sumolib.checkBinary("sumo-gui" if self.cfg.gui else "sumo")
        traci.start([binary, "-n", str(scenario.NET), "-a", str(scenario.STOPS), "-r", str(routes),
                     "--begin", str(self.cfg.begin), "--seed", str(self.cfg.seed),
                     "--time-to-teleport", "300", "--no-step-log", "true", "--no-warnings", "true",
                     *self.cfg.extra_sumo_args], label=self.label)
        self.conn = traci.getConnection(self.label)

        self.t = float(self.cfg.begin)
        self.onboard = defaultdict(list)
        self.last_stop = {}
        self.at_stop = set()
        self.release = {}
        self.pending = {}          # bus -> (obs, dwell)
        self.depart_t = {}
        self.arrivals, self.trips_done, self.passengers, self.holds = [], [], [], []
        self.hold_by_event = []
        self.teleports = 0
        self.finished = set()
        self._speed_hour = None
        self.episode_id = f"{self.cfg.scenario}-{self.cfg.policy}-s{self.cfg.seed}"
        self.done = False
        return self._advance()

    def close(self):
        if self.conn is not None:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None

    # ------------------------------------------------------------- dynamics
    def _apply_speeds(self):
        hour = int(self.t // 3600)
        if self._speeds is None or hour == self._speed_hour:
            return
        self._speed_hour = hour
        edge_speed, corridor = self._speeds
        hours = sorted(corridor)
        h = min(max(hour, hours[0]), hours[-1])
        for d in self.dirs.values():
            for e in d.edges:
                limit = self.conn.lane.getMaxSpeed(f"{e}_0")
                speed = edge_speed.get((e, h), corridor[h])
                self.conn.edge.setMaxSpeed(e, min(limit, speed))

    def _observe(self, bus, d, k):
        t = self.t
        fwd = t - d.last_arrival[k] if d.last_arrival[k] is not None else None
        bwd = None
        f = d.follower.get(bus)
        if f is not None and f not in self.finished:
            if f in self.last_stop:
                kf, tf = self.last_stop[f]
                expected = tf + d.sched[f][k] - d.sched[f][kf] if kf < k else t
            else:
                expected = max(d.depart[f], t) + d.sched[f][k] - d.sched[f][0]
            bwd = max(0.0, expected - t)
        x, y = self.conn.vehicle.getPosition(bus)
        lon, lat = self.conn.simulation.convertGeo(x, y)
        return BusObservation(
            bus_id=bus, route_id=scenario.ROUTE_ID, t=t, stop_idx=k, lat=lat, lon=lon,
            fwd_headway_s=fwd, bwd_headway_s=bwd, sched_dev_s=t - d.sched[bus][k],
            load=len(self.onboard[bus]), waiting_at_stop=len(d.demand.queue[k]),
            scheduled_headway_s=d.sched_hw[bus][k], can_hold=0 < k < d.n - 1)

    def _arrive(self, bus, d, k):
        t = self.t
        d.demand.update(k, t)
        obs = self._observe(bus, d, k)
        staying = []
        alight = 0
        for p in self.onboard[bus]:
            if p.dest == k:
                alight += 1
                self.passengers.append(PassengerTrip(
                    wait_s=p.board_t - p.arrive_t, in_vehicle_s=t - p.board_t,
                    reference_in_vehicle_s=d.sched[bus][k] - d.sched[bus][p.origin]))
            else:
                staying.append(p)
        self.onboard[bus] = staying
        board = 0
        while d.demand.queue[k] and len(staying) < self.cfg.capacity:
            p = d.demand.queue[k].popleft()
            p.board_t = t
            staying.append(p)
            board += 1
        dwell = self.cfg.dwell_fixed_s + self.cfg.board_s * board + self.cfg.alight_s * alight
        self.arrivals.append(StopArrival(
            **obs.model_dump(), episode_id=self.episode_id, trip_id=bus, pattern_id=d.pattern_id,
            stop_id=d.stops[k], scenario=self.cfg.scenario, policy=self.cfg.policy, seed=self.cfg.seed,
            dwell_s=dwell, hour_ist=int(t // 3600) % 24, data_source="simulation"))
        d.last_arrival[k] = t
        self.last_stop[bus] = (k, t)
        if obs.can_hold:
            self.pending[bus] = (obs, dwell)
        else:
            self.release[bus] = t + math.ceil(dwell)

    def _advance(self):
        """Run SUMO until a holding decision is needed or the episode ends."""
        conn = self.conn
        while True:
            conn.simulationStep()
            self.t = conn.simulation.getTime()
            self._apply_speeds()
            self.teleports += conn.simulation.getStartingTeleportNumber()
            for v in conn.simulation.getDepartedIDList():
                self.depart_t[v] = self.t
            for v in conn.simulation.getArrivedIDList():
                self.finished.add(v)
                if v in self.depart_t:
                    self.trips_done.append(VehicleTrip(departure_s=self.depart_t[v], arrival_s=self.t))
                self.at_stop.discard(v)
                self.release.pop(v, None)
            for v, t_rel in list(self.release.items()):
                if self.t >= t_rel:
                    conn.vehicle.resume(v)
                    del self.release[v]
                    self.at_stop.discard(v)
            for v in conn.vehicle.getIDList():
                if v in self.at_stop or v not in self.dir_of or not conn.vehicle.isAtBusStop(v):
                    continue
                d = self.dir_of[v]
                nxt = conn.vehicle.getStops(v, 1)
                if not nxt or nxt[0].stoppingPlaceID not in d.stop_index:
                    continue
                self.at_stop.add(v)
                self._arrive(v, d, d.stop_index[nxt[0].stoppingPlaceID])
            if self.pending:
                return {bus: obs for bus, (obs, _) in self.pending.items()}
            if len(self.finished) >= len(self.all_trips) or conn.simulation.getMinExpectedNumber() == 0:
                self.done = True
                self.close()
                return {}

    def step(self, holds_s):
        """holds_s: {bus_id: hold seconds}, one of config holding.actions_s. Missing buses hold 0."""
        for bus, (obs, dwell) in self.pending.items():
            hold = int(holds_s.get(bus, 0))
            if hold not in self.actions_s:
                raise ValueError(f"Hold {hold}s for {bus} is not one of {self.actions_s}")
            self.release[bus] = self.t + math.ceil(dwell) + hold
            self.holds.append(hold)
            self.hold_by_event.append((bus, obs.stop_idx, self.t, hold))
        self.pending = {}
        return self._advance()

    # ------------------------------------------------------------- results
    def kpis(self):
        k = compute_kpis(self.arrivals, self.passengers, self.trips_done,
                         bunching_ratio=self.settings.bunching.ratio)
        k["mean_hold_s"] = mean(self.holds) if self.holds else 0.0
        k["teleports"] = self.teleports
        k["max_load"] = max((a.load for a in self.arrivals), default=0)
        for ratio in self.settings.bunching.sensitivity_ratios:
            flags = [a.fwd_headway_s < ratio * a.scheduled_headway_s for a in self.arrivals
                     if a.fwd_headway_s is not None and a.scheduled_headway_s is not None]
            k[f"bunched_pct_r{int(ratio * 100)}"] = 100 * mean(flags) if flags else None
        flags = [a.fwd_headway_s < 0.5 * a.scheduled_headway_s for a in self.arrivals
                 if a.fwd_headway_s is not None and a.scheduled_headway_s is not None]
        k["bunched_pct_r50"] = 100 * mean(flags) if flags else None
        return k
