"""Build the 375-D scenario files from the city-wide SUMO import.

gtfs2pt.py placed several 375-D stops on the opposite side of the road, which made the
imported bus routes U-turn to reach them. This script re-snaps every stop to the side of
the road that gives the shortest route through all stops, rebuilds the route, and cuts the
network down to the roads 375-D uses.

Creates, in runs/sumo/:
    375d.net.xml          network with only the 375-D roads (loads in about a second)
    375d_stops.add.xml    the 46 bus stops (23 per direction) on the correct side
    375d_routes.json      edges and stop ids for each direction

Run once from the bmtc folder (needs SUMO's netconvert):
    python -m sim.scenario
"""
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if "SUMO_HOME" in os.environ:
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))
import sumolib  # noqa: E402

SUMO_DIR = ROOT / "runs" / "sumo"
GTFS_DIR = ROOT / "data" / "processed" / "gtfs"
ROUTE_ID = "BMTC:f24361ed9448"          # GTFS route_id of 375-D
ROUTE_NAME = "375-D"

# direction name -> (GTFS pattern_id, SUMO route id written by gtfs2pt.py)
DIRECTIONS = {
    "to_kengeri": ("9d5d8519931eadd0", "NjndpGKT:0TM4gTTy"),
    "to_banashankari": ("a92bb518345cd583", "m7SKITzf:0LaNFrgg"),
}

FULL_NET = SUMO_DIR / "bmtc.net.xml"
NET = SUMO_DIR / "375d.net.xml"
STOPS = SUMO_DIR / "375d_stops.add.xml"
ROUTES = SUMO_DIR / "375d_routes.json"
GTFS_VEHICLES = SUMO_DIR / "gtfs_pt_vehicles.add.xml"
GTFS_STOPS = SUMO_DIR / "gtfs_pt_stops.add.xml"
EDGE_SPEEDS = SUMO_DIR / "edge_hour_speeds.csv"
CORRIDOR_SPEEDS = ROOT / "runs" / "gps" / "corridor_hour_speeds.csv"
SCHEDULE = GTFS_DIR / "scheduled_arrivals.csv"
STOP_LENGTH = 15.0


def imported_routes():
    """{direction: [busStop ids in order]} from the gtfs2pt output."""
    root = ET.parse(GTFS_VEHICLES).getroot()
    routes = {r.get("id"): r for r in root.iter("route")}
    return {name: [s.get("busStop") for s in routes[sumo_route].iter("stop")]
            for name, (_, sumo_route) in DIRECTIONS.items()}


def route_definitions():
    """{direction: (edges, [stop ids in order])} of the cleaned scenario."""
    data = json.loads(ROUTES.read_text(encoding="utf-8"))
    return {name: (d["edges"], d["stops"]) for name, d in data.items()}


def reverse_id(edge_id):
    return edge_id[1:] if edge_id.startswith("-") else "-" + edge_id


def snap_direction(net, stops):
    """Choose a side of the road for each stop so the route through all of them is shortest.

    stops: list of (name, edge_id, midpoint position). Returns (edges, [(edge, pos, name)]).
    """
    def candidates(edge_id, pos):
        out = []
        for eid, p in ((edge_id, pos), (reverse_id(edge_id), None)):
            if not net.hasEdge(eid):
                continue
            edge = net.getEdge(eid)
            if not edge.allows("bus"):
                continue
            if p is None:
                p = edge.getLength() - pos
            out.append((edge, min(max(p, 0.0), edge.getLength())))
        return out

    cands = [candidates(edge_id, pos) for _, edge_id, pos in stops]
    cache = {}

    def link(a, b):
        (ea, pa), (eb, pb) = a, b
        if ea == eb and pb >= pa:
            return pb - pa, [ea]
        key = (ea.getID(), eb.getID())
        if key not in cache:
            cache[key] = net.getShortestPath(ea, eb, vClass="bus")
        path, cost = cache[key]
        if path is None:
            return float("inf"), None
        return cost - pa - (eb.getLength() - pb), list(path)

    best = [{j: (0.0, None, None) for j in range(len(cands[0]))}]
    for i in range(1, len(cands)):
        layer = {}
        for j, cur in enumerate(cands[i]):
            options = []
            for jp, (cost, _, _) in best[-1].items():
                c, path = link(cands[i - 1][jp], cur)
                options.append((cost + c, jp, path))
            layer[j] = min(options, key=lambda o: o[0])
        best.append(layer)

    j = min(best[-1], key=lambda k: best[-1][k][0])
    if best[-1][j][0] == float("inf"):
        raise RuntimeError("No bus route connects the stops")
    chosen, paths = [], []
    for i in range(len(cands) - 1, -1, -1):
        chosen.append(cands[i][j])
        _, jp, path = best[i][j]
        paths.append(path)
        j = jp
    chosen.reverse()
    paths.reverse()
    edges = [chosen[0][0].getID()]
    for path in paths[1:]:
        for e in path:
            if e.getID() != edges[-1]:
                edges.append(e.getID())
    return edges, [(e.getID(), p, name) for (e, p), (name, _, _) in zip(chosen, stops)]


def build():
    stop_xml = {s.get("id"): s for s in ET.parse(GTFS_STOPS).getroot().iter("busStop")}
    print("Reading the full network (about a minute)...")
    net = sumolib.net.readNet(str(FULL_NET))
    routes, stop_lines, all_edges = {}, [], set()
    for name, stop_ids in imported_routes().items():
        stops = []
        for sid in stop_ids:
            s = stop_xml[sid]
            lane = s.get("lane")
            mid = (float(s.get("startPos")) + float(s.get("endPos"))) / 2
            stops.append((s.get("name", sid), lane.rsplit("_", 1)[0], mid))
        edges, snapped = snap_direction(net, stops)
        ids = []
        for k, (edge_id, pos, stop_name) in enumerate(snapped):
            length = net.getEdge(edge_id).getLength()
            end = min(length, max(pos + STOP_LENGTH / 2, min(STOP_LENGTH, length)))
            start = max(0.0, end - STOP_LENGTH)
            sid = f"{name}_{k:02d}"
            ids.append(sid)
            stop_lines.append(f'    <busStop id="{sid}" lane="{edge_id}_0" startPos="{start:.2f}" '
                              f'endPos="{end:.2f}" friendlyPos="true" name="{stop_name.replace(chr(34), "")}"/>')
        moved = sum(a[1] != b[0] for a, b in zip(stops, snapped))
        uturns = sum(edges[i + 1] == reverse_id(edges[i]) for i in range(len(edges) - 1))
        print(f"{name}: {len(ids)} stops ({moved} moved to the other side), {len(edges)} edges, "
              f"{uturns} U-turns left")
        routes[name] = {"edges": edges, "stops": ids}
        all_edges.update(edges)

    edge_file = SUMO_DIR / "375d_edges.txt"
    edge_file.write_text("\n".join(sorted(all_edges)), encoding="utf-8")
    netconvert = sumolib.checkBinary("netconvert")
    subprocess.run([netconvert, "-s", str(FULL_NET), "--keep-edges.input-file", str(edge_file),
                    "-o", str(NET), "--no-warnings", "true"], check=True)
    STOPS.write_text("<additional>\n" + "\n".join(stop_lines) + "\n</additional>\n", encoding="utf-8")
    ROUTES.write_text(json.dumps(routes, indent=1), encoding="utf-8")
    print(f"Wrote {NET.name} ({len(all_edges)} edges), {STOPS.name} and {ROUTES.name}")


if __name__ == "__main__":
    build()
