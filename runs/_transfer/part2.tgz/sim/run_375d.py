"""Compare Varun's four rule-based holding methods on route 375-D.

From the bmtc folder:
    python -m sim.run_375d                          # 4 policies x 5 seeds, both directions
    python -m sim.run_375d --seeds 1 --policies no_control --gui   # watch one run
Outputs go to runs/holding/.
"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

from control.baselines import BaselinePolicy
from sim.bus_sim import BusSim, SimConfig

OUT_DIR = Path(__file__).resolve().parents[1] / "runs" / "holding"
POLICIES = ("no_control", "schedule", "daganzo", "two_headway")
SUMMARY = [("headway_cv", "Headway CV", "{:.3f}"), ("bunched_pct_r50", "Bunched % (<50% headway)", "{:.1f}"),
           ("bunched_arrivals_pct", "Bunched % (<20%, Varun)", "{:.2f}"),
           ("mean_passenger_wait_s", "Mean wait (s)", "{:.0f}"),
           ("mean_in_vehicle_delay_s", "In-vehicle delay vs schedule (s)", "{:.0f}"),
           ("mean_trip_time_s", "Trip time (s)", "{:.0f}"), ("mean_hold_s", "Mean hold (s)", "{:.1f}")]


def run_policy(name, seed, cfg_kwargs):
    sim = BusSim(SimConfig(seed=seed, policy=name, **cfg_kwargs))
    policy = BaselinePolicy(name, sim.settings.holding)
    obs = sim.reset()
    while not sim.done:
        obs = sim.step(policy.act(obs))
    return sim


def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def plot(results, sims):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    keys = [("headway_cv", "Headway CV"), ("bunched_pct_r50", "Bunched arrivals (%)\n(gap < 50% of scheduled)"),
            ("mean_passenger_wait_s", "Mean passenger wait (s)"), ("mean_trip_time_s", "Mean trip time (s)")]
    fig, axes = plt.subplots(1, 4, figsize=(17, 4.2))
    for ax, (key, label) in zip(axes, keys):
        vals = [[r[key] for r in results if r["policy"] == p and r[key] is not None] for p in POLICIES]
        means = [mean(v) if v else 0 for v in vals]
        errs = [stdev(v) if len(v) > 1 else 0 for v in vals]
        ax.bar(POLICIES, means, yerr=errs, capsize=4, color=["#9E9E9E", "#4C78A8", "#F58518", "#54A24B"])
        ax.set_title(label, fontsize=10)
        ax.tick_params(axis="x", rotation=25)
    fig.suptitle("Route 375-D, 07:00-11:00, both directions (mean ± sd over seeds)")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "comparison.png", dpi=150)
    plt.close(fig)

    fig, axes = plt.subplots(2, 2, figsize=(15, 9), sharex=True)
    for col, p in enumerate(("no_control", "daganzo")):
        sim = sims.get(p)
        if sim is None:
            continue
        for row, direction in enumerate(sim.dirs):
            ax = axes[row][col]
            paths = defaultdict(list)
            for a in sim.arrivals:
                if a.pattern_id == sim.dirs[direction].pattern_id:
                    paths[a.bus_id].append((a.t / 3600, a.stop_idx))
            for pts in paths.values():
                pts.sort()
                ax.plot([x for x, _ in pts], [y for _, y in pts], lw=0.8)
            ax.set_title(f"{p} — {direction.replace('_', ' ')}", fontsize=10)
            ax.set_ylabel("Stop index")
    for ax in axes[1]:
        ax.set_xlabel("Time of day (h)")
    fig.suptitle("Time-space diagrams (one line per bus; lines touching = bunching)")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "time_space.png", dpi=150)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policies", nargs="+", default=list(POLICIES), choices=POLICIES)
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--demand", type=float, default=SimConfig.demand_per_min,
                    help="passengers per minute per stop, off-peak")
    ap.add_argument("--no-gps-speeds", action="store_true", help="use OSM speed limits instead")
    ap.add_argument("--begin", type=int, default=SimConfig.begin)
    ap.add_argument("--end", type=int, default=SimConfig.end)
    ap.add_argument("--gui", action="store_true")
    args = ap.parse_args()

    cfg = dict(demand_per_min=args.demand, gps_speeds=not args.no_gps_speeds,
               begin=args.begin, end=args.end, gui=args.gui)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    results, sims = [], {}
    for p in args.policies:
        for seed in range(1, args.seeds + 1):
            sim = run_policy(p, seed, cfg)
            k = sim.kpis()
            results.append({"policy": p, "seed": seed, **k})
            print(f"{p:12} seed {seed}: CV {k['headway_cv']:.3f}  bunched(<50%) {k['bunched_pct_r50']:.1f}%  "
                  f"wait {k['mean_passenger_wait_s']:.0f}s  trip {k['mean_trip_time_s']:.0f}s  "
                  f"max load {k['max_load']}  teleports {k['teleports']}", flush=True)
            write_csv(OUT_DIR / f"arrivals_{p}_s{seed}.csv", [a.model_dump() for a in sim.arrivals])
            sims.setdefault(p, sim)

    write_csv(OUT_DIR / "results.csv", results)
    summary = []
    for p in args.policies:
        rows = [r for r in results if r["policy"] == p]
        summary.append({"policy": p, **{key: mean(r[key] for r in rows if r[key] is not None)
                                        for key, _, _ in SUMMARY}})
    write_csv(OUT_DIR / "summary.csv", summary)
    print("\n" + f"{'':14}" + "".join(f"{label[:18]:>20}" for _, label, _ in SUMMARY))
    for row in summary:
        print(f"{row['policy']:14}" + "".join(f"{fmt.format(row[key]):>20}" for key, _, fmt in SUMMARY))
    plot(results, sims)
    print(f"\nSaved results.csv, summary.csv, comparison.png and time_space.png in {OUT_DIR}")


if __name__ == "__main__":
    main()
